GSEA Desktop input files prepared from: DESeq2_DEGs_padj_lt_0.05.csv

Contrast detected:
  ctrl_1-ctrl_2__cHet_3-cHet_4

Input summary:
  Total rows read: 2318
  Rows with padj < 0.05: 2318
  Upregulated genes (log2FoldChange > 0): 1282
  Downregulated genes (log2FoldChange < 0): 1036
  Minimum padj: 6.63688e-165
  Maximum padj in exported data: 0.0499924
  Duplicate gene symbols after filtering: 0
  Duplicate Ensembl gene IDs after filtering: 0

Recommended GSEA Desktop workflow:
  Use "GSEAPreranked".
  For the Ranked List input, choose one of these .rnk files:
    1) ctrl_1-ctrl_2_vs_cHet_3-cHet_4_padj_lt_0.05_geneSymbol_DESeq2_stat.rnk        RECOMMENDED if your gene set database uses mouse gene symbols.
    2) ctrl_1-ctrl_2_vs_cHet_3-cHet_4_padj_lt_0.05_ensemblGeneID_DESeq2_stat.rnk     Use this if your gene set database uses Ensembl gene IDs.

Alternative ranking files included:
  - log2FoldChange.rnk ranks by effect size.
  - signed_neglog10_padj.rnk ranks by statistical significance with direction.

Important note:
  This uploaded file contains only genes with padj < 0.05. Classic preranked GSEA is usually strongest when run on all tested genes ranked by DESeq2 stat, not only significant DEGs. These files follow the uploaded data exactly, but if you have the full DESeq2 all-gene result table, use that to make a full ranked list for GSEA.

File format notes:
  - .rnk files are tab-delimited with no header: gene_id<TAB>score.
  - Positive scores correspond to genes higher in the second group in the DESeq2 contrast direction as encoded by log2FoldChange.
  - Gene lists are simple one-gene-per-line text files for quick inspection or other enrichment tools.
