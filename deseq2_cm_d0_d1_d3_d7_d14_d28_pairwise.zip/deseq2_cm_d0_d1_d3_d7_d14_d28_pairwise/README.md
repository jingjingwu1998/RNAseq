# Six-timepoint CM DESeq2 pairwise analysis

Twenty-four CM libraries are used: four each at D0, D1, D3, D7, D14, and D28. Salmon NumReads are mapped with Ensembl GRCm38 release 87 and imported through tximport.

DESeq2 fits design ~ timepoint across all 24 samples. The raw-count prefilter is at least 10 input counts in at least four samples. Each pairwise table will contain the eight relevant raw and normalized sample count columns, plus full DESeq2 statistics without output-level significance filtering.
